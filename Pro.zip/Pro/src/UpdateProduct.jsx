import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { updateProduct } from './Service/ItemService';

const UpdateProductForm = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const initialProduct = location.state?.product || {
        name: '',
        category: '',
        price: '',
        quantity: '',
        image: null,
        base64Image: ''
    };

    const [product, setProduct] = useState(initialProduct);
    const [flashMessage, setFlashMessage] = useState('');

    const handleChange = (e) => {
        const { name, value } = e.target;
        setProduct((prev) => ({ ...prev, [name]: value }));
    };

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            setProduct((prev) => ({
                ...prev,
                image: file,
                base64Image: URL.createObjectURL(file)
            }));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const formData = new FormData();
        formData.append("name", product.name);
        formData.append("category", product.category);
        formData.append("price", product.price);
        formData.append("quantity", product.quantity);
        if (product.image) {
            formData.append("image", product.image);
        }

            await updateProduct(product.productId, formData);
            setFlashMessage('Product updated successfully!');
            setTimeout(() => {
                setFlashMessage('');
                navigate('/product-list');
            }, 2000);
        
    };

    return (
        <div>
            <h2>Edit Product</h2>
            {flashMessage && <div className="flash-message">{flashMessage}</div>}
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Product Name:</label>
                    <input type="text" name="name" value={product.name} onChange={handleChange}
                        required
                    />
                </div>
                <div>
                    <label>Category:</label>
                    <input type="text" name="category" value={product.category} onChange={handleChange}
                        required
                    />
                </div>
                <div>
                    <label>Price:</label>
                    <input type="number" name="price" value={product.price}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div>
                    <label>Quantity:</label>
                    <input
                        type="number" name="quantity" value={product.quantity} onChange={handleChange}
                        required
                        min="1"
                    />
                </div>
                <div>
                    <label>Current Image:</label>
                    {product.base64Image ? (
                        <img
                            src={product.base64Image} alt={product.name} style={{ width: '100px', height: '60px' }}
                        />
                    ) : (
                        "No image available"
                    )}
                </div>
                <div>
                    <label>Change Image:</label>
                    <input
                        type="file" accept="image/*" onChange={handleImageChange}
                    />
                </div>
                <button type="submit">Update Product</button>
            </form>
        </div>
    );
};

export default UpdateProductForm;
