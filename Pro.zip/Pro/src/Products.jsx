import React, { useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { saveProduct } from './Service/ItemService';
import './ProductForm.css';

const ProductEx = () => {
    const nameRef = useRef();
    const categoryRef = useRef();
    const priceRef = useRef();
    const quantityRef = useRef();
    const imageRef = useRef();
    const [message, setMessage] = useState('');
    const [flashType, setFlashType] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage('');

        const formData = new FormData();
        formData.append('name', nameRef.current.value);
        formData.append('category', categoryRef.current.value);
        formData.append('price', parseFloat(priceRef.current.value));
        formData.append('quantity', parseInt(quantityRef.current.value, 10) || 0);
        formData.append('image', imageRef.current.files[0]);

      
            const response = await saveProduct(formData); 
            if (response.status === 201) {
                setMessage('Product saved successfully!');
                setFlashType('success');
                setTimeout(() => navigate('/product-list'), 3000);
            } 
        
    };

    return (
        <div className="product-form-container">
            <h2 className="form-title">Add New Product</h2>
            {message && <p className={`form-message ${flashType}`}>{message}</p>}
            <form className="product-form" onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>Product Name:</label>
                    <input type="text" ref={nameRef} required />
                </div>
                <div className="form-group">
                    <label>Category:</label>
                    <input type="text" ref={categoryRef} required />
                </div>
                <div className="form-group">
                    <label>Price:</label>
                    <input type="number" ref={priceRef} required min="0" />
                </div>
                <div className="form-group">
                    <label>Quantity:</label>
                    <input type="number" ref={quantityRef} required min="1" />
                </div>
                <div className="form-group">
                    <label>Image:</label>
                    <input type="file" accept="image/*" ref={imageRef} required />
                </div>
                <button type="submit" className="submit-button">Save Product</button>
            </form>
        </div>
    );
};

export default ProductEx;
