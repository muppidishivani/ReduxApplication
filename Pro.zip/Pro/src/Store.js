import { configureStore, createSlice } from '@reduxjs/toolkit';
import cartReducer from './CartSlice.js';

// Create a slice for managing items
const itemsSlice = createSlice({
  name: 'items',
  initialState: {
    veg: [],
    nonVeg: [],
  },
  reducers: {
    setVegItems: (state, action) => {
      state.veg = action.payload; // Store veg items in Redux state
    },
    setNonVegItems: (state, action) => {
      state.nonVeg = action.payload; // Store non-veg items in Redux state
    },
  },
});


export const { setVegItems, setNonVegItems } = itemsSlice.actions;


const store = configureStore({
  reducer: {
    items: itemsSlice.reducer, 
    cart: cartReducer, 
  },
  devTools: process.env.NODE_ENV !== 'production', 
});


export default store;
