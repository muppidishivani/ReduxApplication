
import axios from 'axios';
import { setVegItems,setNonVegItems } from '../Store';



export const fetchAndDispatchItems = async (dispatch) => {
    
        const response = await axios.get('http://localhost:8001/products'); 

        // Filter items by category
        const vegItems = response.data.filter(item => item.category === 'Veg');
        const nonVegItems = response.data.filter(item => item.category === 'Non-veg');

        // Dispatch the filtered data to the store
        dispatch(setVegItems(vegItems));
        dispatch(setNonVegItems(nonVegItems));
    
};
export const saveProduct = (formData) => {
    return axios.post(`http://localhost:8001/add`, formData);
    
};

    // get the product list

    export const fetchProducts =  async() => {
        const response = await  axios.get('http://localhost:8001/products');
        return response.data;
    };

    //delete the product based on id
    export const deleteProduct = async (productId) => {
        await axios.delete(`http://localhost:8001/deletepro/${productId}`);
    };

    //fetch the product based on id
    export const fetchProductById = async (productId) => {
        const response = await axios.get(`http://localhost:8001/get/${productId}`);
        return response.data;
    };

    // Update product data
    export const updateProduct = async (productId, formData) => {
        await axios.put(`http://localhost:8001/update/${productId}`, formData, {
          
        });
    };













