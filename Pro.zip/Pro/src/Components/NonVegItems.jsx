
import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { addToCart } from '../CartSlice';
import './NonVegItems.css';

const NonVegItems = () => {
  const nonVegItems = useSelector((state) => state.items.nonVeg);
  const dispatch = useDispatch();

  const handleAddToCart = (item) => {
    dispatch(addToCart(item)); // Dispatch addToCart action
  };

  return (
    <div className="non-veg-container">
      <h2 className="non-veg-title">Non-Veg Items</h2>
      <ul className="non-veg-list">
        {nonVegItems.length > 0 ? (
          nonVegItems.map((item) => (
            <li key={item.id} className="non-veg-item">
              <p><strong>ID:</strong> {item.id}</p>
              <p><strong>Name:</strong> {item.name}</p>
              <p><strong>Price:</strong> ${item.price.toFixed(2)}</p>
              <p><strong>Product Image:</strong></p>
              {item.image ? (
                <img
                  src={`data:image/jpeg;base64,${item.image}`} 
                  alt={item.name}
                  style={{ width: '100px', height: '100px' }} 
                />
              ) : (
                <p>No image available</p> 
              )}<br></br>
              
              <button onClick={() => handleAddToCart(item)}>Add to Cart</button> 
            </li>
          ))
        ) : (
          <p>No non-vegetarian items available.</p> 
        )}
      </ul>
    </div>
  );
};

export default NonVegItems;