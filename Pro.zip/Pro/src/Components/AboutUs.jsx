// src/components/AboutUs.jsx
import React from 'react';
import './App.css'; // Import CSS for styling

const AboutUs = () => (
  <div className="about-container">
    <h1 className="about-title">About Us</h1>
    <p className="about-description">
      We are dedicated to providing high-quality, delicious meals that cater to every palate. 
      Our mission is to create memorable dining experiences with every order.
    </p>

   

    <h2 className="about-heading">Join Us</h2>
    <p>
      Explore our menu and discover your new favorite dish. Let us bring the joy of food to your doorstep!
    </p>
  </div>
);

export default AboutUs;
