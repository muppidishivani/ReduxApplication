import React from 'react';
import { useSelector } from 'react-redux';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import VegItems from './VegItems';
import NonVegItems from './NonVegItems';
import Home from './Home';
import AboutUs from './AboutUs';
import ContactUs from './ContactUs';
import Cart from './Cart';
import ProductList from '../GetProducts';
import ProductForm from '../Products';
import UpdateProductForm from '../UpdateProduct';
import './App.css';

const App = () => {
  const cartItems = useSelector((state) => state.cart.items);

  return (
    <Router>
      <nav className="navbar">
        <Link to="/" className="nav-link">Home</Link>
        <Link to="/veg-items" className="nav-link">Veg Items</Link>
        <Link to="/non-veg-items" className="nav-link">Non-Veg Items</Link>
        <Link to="/about-us" className="nav-link">About Us</Link>
        <Link to="/contact-us" className="nav-link">Contact Us</Link>
        <Link to="/product" className="nav-link">Products</Link>
        <Link to="/product-list" className="nav-link">Products List</Link>
        <Link to="/cart" className="nav-link">Cart ({cartItems.length})</Link>
      </nav>

      <div className="content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/veg-items" element={<VegItems />} />
          <Route path="/non-veg-items" element={<NonVegItems />} />
          <Route path="/about-us" element={<AboutUs />} />
          <Route path="/contact-us" element={<ContactUs />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/product" element={<ProductForm />} />
          <Route path="/edit-product/:productId" element={<UpdateProductForm />} />
          <Route path="/product-list" element={<ProductList />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
