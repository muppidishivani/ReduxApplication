// src/components/VegItems.jsx
import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { addToCart } from '../CartSlice';
import './VegItems.css';

const VegItems = () => {
  const vegItems = useSelector((state) => state.items.veg); // Access veg items from Redux state
  const dispatch = useDispatch();

  const handleAddToCart = (item) => {
    dispatch(addToCart(item)); // Dispatch addToCart action
  };

  return (
    <div className="veg-container">
      <h2 className="veg-title">Veg Items</h2>
      <ul className="veg-list">
        {vegItems.length > 0 ? (
          vegItems.map((item) => (
            <li key={item.id} className="veg-item">
              <p><strong>ID:</strong> {item.id}</p>
              <p><strong>Name:</strong> {item.name}</p>
              <p><strong>Price:</strong> ${item.price.toFixed(2)}</p>
              <p><strong>Product Image:</strong></p>
              {item.image ? (
                <img
                  src={`data:image/jpeg;base64,${item.image}`} // Display the product image
                  alt={item.name}
                  style={{ width: '100px', height: '100px' }} // Set image dimensions
                />
              ) : (
                <p>No image available</p> // Message when no image is available
              )}
              <br />
              <button onClick={() => handleAddToCart(item)}>Add to Cart</button>
            </li>
          ))
        ) : (
          <p>No vegetarian items available.</p> // Message when no items are available
        )}
      </ul>
    </div>
  );
};

export default VegItems;
