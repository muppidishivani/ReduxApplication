import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { removeFromCart,clearCart } from '../CartSlice';
import '../Cart.css';

const Cart = () => {
  
  const cartItems = useSelector((state) => state.cart.items);
  
  const dispatch = useDispatch();

  
  const handleRemoveFromCart = (item) => {
    dispatch(removeFromCart(item)); 
  };

  
  const handleClearCart = () => {
    dispatch(clearCart()); 
  };

  return (
    <div className="cart-container">
      <h2 className="cart-title">Shopping Cart</h2>
      {cartItems.length > 0 ? (
        <>
          <ul className="cart-list">
            {cartItems.map((item) => (
              <li key={item.id} className="cart-item">
                <p><strong>ID:</strong> {item.id}</p>
                <p><strong>Name:</strong> {item.name}</p>
                <p><strong>Price:</strong> ${item.price.toFixed(2)}</p>
                <p><strong>Quantity:</strong> {item.quantity}</p>
                <button onClick={() => handleRemoveFromCart(item)}>Remove</button>
              </li>
            ))}
          </ul>
          <button className="clear-cart-button" onClick={handleClearCart}>
            Clear Cart
          </button>
        </>
      ) : (
        <p>Your cart is empty.</p> 
      )}
    </div>
  );
};

export default Cart;
