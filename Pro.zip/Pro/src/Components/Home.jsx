// src/components/Home.jsx
import React from 'react';
import './App.css'; // Import the CSS styles

const Home = () => (
  <div className="home-container">
    <div className="hero-section">
      <h2 className="hero-title">Welcome to Food Menu!</h2>
      <p className="hero-subtitle">Your favorite meals delivered to your doorstep.</p>
     
    </div>

    <div className="features-section">
      <h2 className="features-title">Why Choose Us?</h2>
      <ul className="features-list">
        <li>🍽️ **Diverse Menu**: Explore a wide variety of Veg and Non-Veg dishes.</li>
        <li>🚚 **Fast Delivery**: Get your meals delivered quickly and efficiently.</li>
        <li>💰 **Affordable Prices**: Enjoy delicious food at competitive prices.</li>
        <li>⭐ **Customer Satisfaction**: We prioritize our customers' happiness with every order.</li>
      </ul>
    </div>

    
    
  </div>
);

export default Home;
