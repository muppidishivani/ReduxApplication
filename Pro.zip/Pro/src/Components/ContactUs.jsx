// src/components/ContactUs.jsx
import React from 'react';
import './App.css'; // Import CSS for styling

const ContactUs = () => (
  <div className="contact-container">
    <h1 className="contact-title">Contact Us</h1>
    <p className="contact-description">
      We’re here to help! If you have any questions, comments, please don't hesitate to reach out to us.
    </p>
    
    <div className="contact-details">
      <h2 className="contact-heading">Get in Touch</h2>
      <p>
        📧 <strong>Email:</strong> <a href="mailto:info@foodmenu.com">info@foodmenu.com</a>
      </p>
      <p>
        📞 <strong>Phone:</strong> <a href="tel:+11234567890">(123) 456-7890</a>
      </p>
      <p>
        🕒 <strong>Business Hours:</strong> Monday to Friday, 9 AM to 6 PM
      </p>
    </div>

    <div className="social-media">
      <h2 className="social-media-heading">Follow Us</h2>
      <p>
        Stay updated with our latest offers and updates on social media!
      </p><br></br>
      <ul className="social-media-list">
        <li><a href="https://www.facebook.com/yourpage" target="_blank" rel="noopener noreferrer">Facebook</a></li>
        <li><a href="https://www.twitter.com/yourprofile" target="_blank" rel="noopener noreferrer">Twitter</a></li>
        <li><a href="https://www.instagram.com/yourprofile" target="_blank" rel="noopener noreferrer">Instagram</a></li>
        <li><a href="https://www.linkedin.com/company/yourcompany" target="_blank" rel="noopener noreferrer">LinkedIn</a></li>
      </ul>
    </div>

   
  </div>
);

export default ContactUs;
