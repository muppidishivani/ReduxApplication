import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { fetchProducts as fetchProductsFromService, deleteProduct as deleteProductFromService } from './Service/ItemService';
import './ProductForm.css';


const ProductList = () => {
    const [products, setProducts] = useState([]);
    const [flashMessage, setFlashMessage] = useState('');
    const navigate = useNavigate();

    
    const fetchProducts = async () => {
        const productsData = await fetchProductsFromService();
        setProducts(productsData);
    };


        fetchProducts();
  
    
    const deleteProduct = async (productId) => {
        await deleteProductFromService(productId);
        setProducts(products.filter((product) => product.id !== productId));
        setFlashMessage('Product deleted successfully');

        
        setTimeout(() => setFlashMessage(''), 3000);
    };

    
    const editProduct = (productId) => {
        navigate(`/edit-product/${productId}`);
    };

    return (
        <div>
            <h1>Product List</h1>
            
            
            {flashMessage && <div className="flash-message">{flashMessage}</div>}

            <table border="1" cellPadding="10" style={{ width: '100%', textAlign: 'left' }}>
                <thead>
                    <tr>
                        <th>Product ID</th>
                        <th>Product Name</th>
                        <th>Category</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Product Image</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {products.map((product) => (
                        <tr key={product.id}>
                            <td>{product.id}</td>
                            <td>{product.name}</td>
                            <td>{product.category}</td>
                            <td>{product.quantity}</td>
                            <td>${product.price}</td>
                            <td>
                                {product.image ? (
                                    <img
                                        src={`data:image/jpeg;base64,${product.image}`}
                                        alt={product.name}
                                        style={{ width: '100px', height: '60px' }}
                                    />
                                ) : (
                                    "No image available"
                                )}
                            </td>
                            <td>
                                <button onClick={() => editProduct(product.id)}>Edit</button>
                                <button onClick={() => deleteProduct(product.id)} style={{ marginLeft: '10px' }}>
                                    Delete
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ProductList;
