
import { createRoot } from 'react-dom/client'
import './index.css'

import { Provider } from 'react-redux';
import store from './Store.js';
import { fetchAndDispatchItems } from './Service/ItemService.js';
import App from './Components/App.jsx';


// Dispatch items once the store is initialized
fetchAndDispatchItems(store.dispatch);

createRoot(document.getElementById('root')).render(
  <Provider store={store}>
  
<App />

  </Provider>,
)
