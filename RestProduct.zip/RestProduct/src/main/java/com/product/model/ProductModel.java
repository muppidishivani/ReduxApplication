package com.product.model;

import org.springframework.web.multipart.MultipartFile;

import jakarta.persistence.Lob;
import lombok.AllArgsConstructor;
import lombok.Data;
@Data
@AllArgsConstructor
public class ProductModel {

	
	private String name;
	 private int quantity;
	 private Double price;
	  private String category;
	   
	 @Lob
	 private MultipartFile image; // Store image as byte array
	   
}
