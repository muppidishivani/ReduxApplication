package com.product.service;

import java.io.IOException;

import java.util.Base64;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.product.entity.Product;
import com.product.model.ProductModel;
import com.product.repository.ProductRepository;

@Service
public class ProductService {

	@Autowired ProductRepository repo;
	
	   //save product
	public Product saveProduct(ProductModel productModel) throws IOException {
        Product product = new Product();
        product.setCategory(productModel.getCategory());
        product.setName(productModel.getName());
        product.setQuantity(productModel.getQuantity());
        product.setPrice(productModel.getPrice());

        // Handle image upload
        MultipartFile image = productModel.getImage();
        if (image != null && !image.isEmpty()) {
            product.setImage(image.getBytes()); // Store image as byte array
        }

        return repo.save(product);
    }
	  // get products
	 public List<Product> getAllProducts() {
	        return repo.findAll();
	    }
	 
	 //delete product
	 public void deleteProduct(long id)
	 {
		 repo.deleteById(id);
	 }
	 
	 //update product
	 public Product updateProduct(Long id, ProductModel productModel) throws IOException {
	        Optional<Product> existingProductOptional = repo.findById(id);
	        if (existingProductOptional.isPresent()) {
	            Product existingProduct = existingProductOptional.get();
	            existingProduct.setName(productModel.getName());
	            existingProduct.setCategory(productModel.getCategory());
	            existingProduct.setPrice(productModel.getPrice());
	            existingProduct.setQuantity(productModel.getQuantity());
	            if (productModel.getImage() != null && !productModel.getImage().isEmpty()) {
	                existingProduct.setImage(productModel.getImage().getBytes());
	            }
	            return repo.save(existingProduct);
	        }
	        return null;
	    }

	    public Product getOneProduct(long id) {
	        return repo.findById(id).orElse(null);
	    }
}

