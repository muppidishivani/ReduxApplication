package com.product.controller;

import java.io.IOException;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.product.entity.Product;
import com.product.model.ProductModel;
import com.product.service.ProductService;

@RestController
@CrossOrigin("*")
public class ProductController {

	@Autowired ProductService service;
	
	  @PostMapping(value = "/add", consumes = "multipart/form-data")
	    public ResponseEntity<Product> addProduct(@ModelAttribute ProductModel productModel) throws IOException {
	        Product savedProduct = service.saveProduct(productModel);
	        return new ResponseEntity<>(savedProduct, HttpStatus.CREATED);
	    }
	 
	  @GetMapping("/products")
	    public ResponseEntity<List<Product>> getAllProducts() {
	        List<Product> products = service.getAllProducts();
	        return ResponseEntity.ok(products);
	    }
	  
	  
	  @DeleteMapping("/deletepro/{id}")
	  public void deleteProduct(@PathVariable long id)
	  {
		  service.deleteProduct(id);
	  }
	  
	  
	  @PutMapping("/update/{id}")
	    public ResponseEntity<Product> updateProduct(@PathVariable Long id, @ModelAttribute ProductModel productModel) throws IOException {
	        Product updatedProduct = service.updateProduct(id, productModel);
	        return updatedProduct != null
	            ? new ResponseEntity<>(updatedProduct, HttpStatus.OK)
	            : new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    }

	    @GetMapping("/get/{id}")
	    public ResponseEntity<Product> getData(@PathVariable long id) {
	        Product product = service.getOneProduct(id);
	        return product != null
	            ? new ResponseEntity<>(product, HttpStatus.OK)
	            : new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    }
}
